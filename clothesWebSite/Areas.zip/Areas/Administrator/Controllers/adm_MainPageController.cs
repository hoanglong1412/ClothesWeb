﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace clothesWebSite.Areas.Administrator.Controllers
{
    public class adm_MainPageController : Controller
    {
        // GET: Admin/adm_MainPage
        public ActionResult Index()
        {
            return View();
        }

    }
}